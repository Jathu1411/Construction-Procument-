package com.crave.food.csse_android_app.listners;

import com.crave.food.csse_android_app.models.Product;

public interface OnProductClicked
{
    public void onChange(Product product);
}
