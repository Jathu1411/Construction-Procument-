package com.crave.food.csse_android_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PaymentCreditDebit extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_credit_debit);


    }
}