package com.crave.food.csse_android_app.models;

public class User
{

}
